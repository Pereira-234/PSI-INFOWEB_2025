from .HomeUrls import *
from .ProdutoUrls import *